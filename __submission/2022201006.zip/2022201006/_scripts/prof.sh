python3 nqprof.py -n 14
python3 fwcfprof.py -n 2500
python3 golprof.py -r 1000 -c 1000 -g 50

